import {aliases, mdi} from 'vuetify/iconsets/mdi' // If using Material Design Icons
import {lightTheme} from './light'
import {darkTheme} from "./dark";

export const theme = {
    themes: {
        light: lightTheme,
        dark: darkTheme
    },
    defaultTheme: 'light',
    icons: {
        defaultSet: 'mdi', // Using Material Design Icons
        aliases,
        sets: {
            mdi,
        },
    },
}